<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function(){
    return view('index');
});

Route::get('/p1', function(){
    return view('ryu');
});

Route::get('/p2', function(){
    return view('ken');
}); 

Route::get('/p3', function(){
    return view('akuma');
}); 

Route::get('/p4', function(){
    return view('blanka');
}); 

Route::get('/p5', function(){
    return view('sagat');
}); 

Route::get('/p6', function(){
    return view('honda');
}); 


